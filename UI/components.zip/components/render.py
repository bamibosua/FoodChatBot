import streamlit as st
import json
import os
import base64
from .logic import parse_user_input, process_logic, generate_reply

from streamlit_folium import st_folium
import folium
from .map_utils import create_multi_destination_map

from UI.config.settings import NUMBER_OF_MESSAGES_TO_DISPLAY
from UI.utils.helpers import save_current_chat, new_chat_id, initialize_conversation

def init_food_state():
    defaults = {
        "history": [],
        "conversation_history": initialize_conversation(),
        "final_data": {"location": None, "city": None, "foods": [], "budget": None},
        "chat_titles": {},
        "favorites": [],
        "pending_user_input": None,
        "filtered_restaurants": {},
    }

    for key, value in defaults.items():
        if key not in st.session_state:
            st.session_state[key] = value

    if "current_chat_id" not in st.session_state:
        st.session_state.current_chat_id = new_chat_id()

    if len(st.session_state.history) == 0:
        welcome = (
            "Hello! I'm your food assistant!\n"
            "Please enter your preferred district in Ho Chi Minh City, "
            "your taste or food you want, and your budget (VND)."
        )
        st.session_state.history.append({"role": "assistant", "content": welcome})
        st.session_state.conversation_history.append(
            {"role": "assistant", "content": welcome}
        )
    
    if "final_data" not in st.session_state:
        st.session_state.final_data = {
            "location": None,
            "city": None,
            "foods": [],
            "budget": None,
        }
    if "city" not in st.session_state:
        st.session_state.city = None
        
def init_map_session_state():
    defaults = {
        "current_location": "",
        "multi_map": None,
        "multi_info": {},
        "show_default_map": True,
        "filtered_restaurants": {},
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

def render_messages():
    for msg in st.session_state.history[-NUMBER_OF_MESSAGES_TO_DISPLAY:]:
        if msg["role"] == "assistant":
            with st.chat_message("assistant", avatar="🤖"):
                st.markdown(msg["content"])
        else:
            with st.chat_message("user", avatar="🙂"):
                st.markdown(msg["content"])

    st.markdown("---")

def load_image_base64(relative_path):
    abs_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), relative_path)
    if not os.path.exists(abs_path):
        raise FileNotFoundError(f"Không tìm thấy file: {abs_path}")
    with open(abs_path, "rb") as f:
        return base64.b64encode(f.read()).decode()

img_base64 = load_image_base64("../imgs/logo.png")

def render_main_chat():
    st.markdown(f"""
        <div class="custom-header">
        <h1>
            <img src="data:image/png;base64,{img_base64}" width="100" style="vertical-align: middle; margin-right: 5px;">
            Tourism Chatbot
        </h1>
        <p>Your intelligent travel companion with route planning</p>
        </div>
    """, unsafe_allow_html=True)
        
    init_food_state()

    current_title = st.session_state.chat_titles.get(
        st.session_state.current_chat_id, "New Chat"
    )
    st.markdown(f"**{current_title}**")

    render_messages()

    if st.session_state.pending_user_input:
        user_msg = st.session_state.pending_user_input
        st.session_state.pending_user_input = None

        # 1️⃣ parse
        parsed_data, original_lang = parse_user_input(user_msg)

        # 2️⃣ xử lý logic (chỉ chạy 1 lần)
        processed_result = process_logic(
            parsed_data,
            original_lang,
            st.session_state.final_data,
            st.session_state.city
        )

        # lưu kết quả vào session_state để dùng cho nhiều mục đích
        st.session_state.processed_result = processed_result
        st.session_state.original_lang_for_result = original_lang
        st.session_state.filtered_restaurants = processed_result.get("processed_data", {})

        # 3️⃣ tạo output bot_reply
        bot_reply = generate_reply(processed_result, original_lang)

        st.session_state.history.append({"role": "assistant", "content": bot_reply})
        st.session_state.conversation_history.append(
            {"role": "assistant", "content": bot_reply}
        )
        
        for key in st.session_state.final_data:
            if key in ["foods", "taste"]:
                st.session_state.final_data[key] = []
            else:
                st.session_state.final_data[key] = None
        
        save_current_chat()
        st.rerun()
        
    user_input = st.chat_input("Type your message...")

    if user_input:
        st.session_state.history.append({"role": "user", "content": user_input})
        st.session_state.conversation_history.append(
            {"role": "user", "content": user_input}
        )
        st.session_state.pending_user_input = user_input
        st.rerun()

    c1, c2, c3, c4 = st.columns([1, 1, 1, 2])

    with c1:
        if st.button("Save"):
            save_current_chat()
            st.success("Saved!")

    with c2:
        if st.button("Clear"):
            st.session_state.history = []
            st.rerun()

    with c3:
        if st.button("Export"):
            data = {
                "chat_id": st.session_state.current_chat_id,
                "title": current_title,
                "messages": st.session_state.history,
            }
            st.download_button(
                "Download JSON",
                json.dumps(data, ensure_ascii=False, indent=2),
                f"chat_{st.session_state.current_chat_id}.json",
                "application/json",
            )

    with c4:
        new_name = st.text_input("Rename", placeholder="New name", label_visibility="collapsed")
        if st.button("Rename") and new_name.strip():
            st.session_state.chat_titles[st.session_state.current_chat_id] = new_name.strip()
            st.success("Renamed!")
            st.rerun()
            
def render_map_sidebar(map_col=None, restaurant_places=None):
    init_map_session_state()
    if map_col is None:
        return

    with map_col:
        st.markdown("## 🗺️ Route")
        
        RESTAURANT_PLACES = restaurant_places or st.session_state.get("filtered_restaurants", {})
        
        # ---------------- INPUT FORM ----------------
        with st.form("location_form", clear_on_submit=False):
            st.text_input(
                "📍 Your Location",
                key="current_location_input",
                placeholder="E.g., District 1, Ho Chi Minh City"
            )
            loc = st.session_state.current_location_input
            submit = st.form_submit_button("🚗 Show Routes", use_container_width=True)

        # ---------------- SUBMIT ----------------
        if submit:
            if not loc.strip():
                st.warning("⚠️ Please enter your location!")
            else:
                st.session_state.current_location = loc.strip()  # ← FIX: dùng biến loc

                with st.spinner("🔄 Creating routes..."):
                    if not RESTAURANT_PLACES:
                        st.error("❌ No restaurants to route to!")
                        st.session_state.multi_map = None
                        st.session_state.multi_info = {}
                        st.session_state.show_default_map = True
                    else:
                        m, info = create_multi_destination_map(loc, RESTAURANT_PLACES)
                        if m and info and not info.get('error'):
                            st.session_state.multi_map = m
                            st.session_state.multi_info = info
                            st.session_state.show_default_map = False
                            st.success(f"✅ Routes created to {len(info)} restaurants!")
                        else:
                            st.error(f"❌ Failed to create routes: {info.get('error', 'Unknown error')}")
                            st.session_state.multi_map = None
                            st.session_state.multi_info = {}
                            st.session_state.show_default_map = True

        # =======================================================
        #          LUÔN HIỂN THỊ MAP - FIX LOGIC
        # =======================================================
        st.markdown("### 🗺️ Map View")

        # ✅ FIX: Kiểm tra route map TRƯỚC
        if st.session_state.multi_map and not st.session_state.get("show_default_map", True):
            st_folium(
                st.session_state.multi_map,
                height=450,
                returned_objects=[],
                key="map_route"
            )

        # Nếu CHƯA có route nhưng CÓ RESTAURANTS → show markers only
        elif RESTAURANT_PLACES:
            m = folium.Map(location=[10.776, 106.7], zoom_start=12)
            for r in RESTAURANT_PLACES:
                if r.get("lat") and r.get("lng"):  # ← FIX: Kiểm tra tọa độ
                    folium.Marker(
                        [r["lat"], r["lng"]],
                        popup=r.get("name", "Restaurant"),
                        icon=folium.Icon(color='blue', icon='utensils', prefix='fa')
                    ).add_to(m)

            st_folium(m, height=450, key="map_restaurants")

        # Không có gì → default map
        else:
            default_map = folium.Map(location=[10.776, 106.7], zoom_start=12)
            st_folium(default_map, height=450, key="map_default")

        # ---------------- ROUTE DETAILS ----------------
        if st.session_state.multi_info and not st.session_state.show_default_map:
            st.markdown("---")
            st.markdown("### 🎯 Route Details")

            icons = "🔵🔴🟣🟠🟤"

            for idx, (name, info) in enumerate(st.session_state.multi_info.items(), 1):
                if 'error' in info:
                    st.error(f"❌ {name}: {info['error']}")
                    continue
                    
                with st.expander(
                    f"{icons[(idx - 1) % len(icons)]} {idx}. {name} - {info['distance_km']:.1f} km",
                    icon="📍",
                    expanded=(idx <= 2)
                ):
                    col1, col2 = st.columns(2)
                    with col1:
                        st.metric("📏 Distance", f"{info['distance_km']:.2f} km")
                    with col2:
                        st.metric("⏱️ Time", f"{info['duration_hrs']*60:.0f} min")
                    st.caption(f"📍 {info.get('address', 'N/A')}")